﻿using Microsoft.Extensions.DependencyInjection;

namespace MasstransitCorrelationId
{
    public static class MasstransitCorrelationIdExtensions
    {
        public static void AddMasstransitCorrelationId(this IServiceCollection services)
        {

        }
    }
}
