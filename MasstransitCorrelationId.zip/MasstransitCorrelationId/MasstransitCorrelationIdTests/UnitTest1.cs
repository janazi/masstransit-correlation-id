using System;
using Xunit;

namespace MasstransitCorrelationIdTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
